def list_to_string(list):
    full_string=""
    for string in list:
        full_string=full_string+" "+string
    return full_string    
