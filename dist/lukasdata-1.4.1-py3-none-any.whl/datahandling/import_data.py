import os
from determine_file_type import determine_file_type

def import_file(file_name):
    file_type=determine_file_type(file_name)
    df_name=


def import_directory():
    for 